package com.example.maps

data class ProductoCarrito(
    val id: Int,
    val name: String,
    val price: String,
    var cantidadCompra: Int
)