package com.example.maps

class ProductoProvider {
    companion object{
        val productoList = mutableListOf<ProductoCarrito>(
//            ProductoCarrito(1,"Botella 625ML Aqua Premium", "$1.00", 10),
//            ProductoCarrito(2,"Botellón 20l Aqua Premium (Liquído)", "$3.00", 5),
        )
    }
}
